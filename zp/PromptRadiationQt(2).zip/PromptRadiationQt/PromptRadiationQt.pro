QT += widgets

CONFIG += c++17 warn_on
CONFIG -= app_bundle

TEMPLATE = app
TARGET = PromptRadiationQt

SOURCES += \
    main.cpp \
    MainWindow.cpp \
    LocationFactorsDialog.cpp \
    LocationFactorsModel.cpp \
    StopBoundariesDialog.cpp \
    PromptRadiationDetailed.cpp

HEADERS += \
    MainWindow.h \
    LocationFactorsDialog.h \
    LocationFactorsModel.h \
    StopBoundariesDialog.h \
    PromptRadiationDetailed.h

DISTFILES += README.md PromptRadiation.ini
