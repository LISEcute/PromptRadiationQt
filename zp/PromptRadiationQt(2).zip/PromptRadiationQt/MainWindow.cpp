#include "MainWindow.h"

#include "LocationFactorsDialog.h"
#include "StopBoundariesDialog.h"
#include "PromptRadiationDetailed.h"

#include <QAction>
#include <QCoreApplication>
#include <QDir>
#include <QMenu>
#include <QMenuBar>
#include <QSettings>
#include <QTextEdit>

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent),
      m_log(new QTextEdit(this))
{
    setWindowTitle(tr("LISE++ Prompt Radiation Qt Example"));
    resize(950, 620);

    m_log->setReadOnly(true);
    setCentralWidget(m_log);

    loadPromptRadiationSettings();
    createMenus();

    m_log->append(tr("Prompt-radiation settings loaded from:\n  %1").arg(settingsFilePath()));
    printLocationFactorSummary();
    printStopBoundarySummary();
}

void MainWindow::createMenus()
{
    // These are the actions you can move into the existing LISE++ menu.
    QMenu* calcMenu = menuBar()->addMenu(tr("&Calculations"));

    QAction* editFactorsAction = calcMenu->addAction(tr("Prompt radiation: edit location factors..."));
    connect(editFactorsAction, &QAction::triggered, this, &MainWindow::editLocationFactors);

    QAction* editBoundariesAction = calcMenu->addAction(tr("Prompt radiation: edit DB0.x stopping boundaries..."));
    connect(editBoundariesAction, &QAction::triggered, this, &MainWindow::editStopLocationBoundaries);

    QAction* runExampleAction = calcMenu->addAction(tr("Prompt radiation: run small example"));
    connect(runExampleAction, &QAction::triggered, this, &MainWindow::runSmallExample);

    calcMenu->addSeparator();

    QAction* resetFactorsAction = calcMenu->addAction(tr("Prompt radiation: reset location factors"));
    connect(resetFactorsAction, &QAction::triggered, this, &MainWindow::resetLocationFactors);

    QAction* resetBoundariesAction = calcMenu->addAction(tr("Prompt radiation: reset DB0.x stopping boundaries"));
    connect(resetBoundariesAction, &QAction::triggered, this, &MainWindow::resetStopLocationBoundaries);

    QMenu* fileMenu = menuBar()->addMenu(tr("&File"));
    QAction* quitAction = fileMenu->addAction(tr("Quit"));
    connect(quitAction, &QAction::triggered, this, &QWidget::close);
}

QString MainWindow::settingsFilePath() const
{
    // Explicit INI file, not the Windows registry. For direct LISE++ integration,
    // change only this path if you prefer the existing LISE++ settings directory.
    return QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("PromptRadiation.ini"));
}

void MainWindow::editLocationFactors()
{
    LocationFactorsDialog dlg(this);
    dlg.setFactors(lise_prompt_rad::locationFactors());

    if (dlg.exec() == QDialog::Accepted) {
        lise_prompt_rad::setLocationFactors(dlg.factors());
        savePromptRadiationSettings();
        m_log->append(tr("\nLocation factors updated from table editor and saved to INI."));
        printLocationFactorSummary();
    }
}

void MainWindow::editStopLocationBoundaries()
{
    StopBoundariesDialog dlg(this);
    dlg.setBoundaries(lise_prompt_rad::stopLocationBoundaries());

    if (dlg.exec() == QDialog::Accepted) {
        lise_prompt_rad::setStopLocationBoundaries(dlg.boundaries());
        savePromptRadiationSettings();
        m_log->append(tr("\nDB0.x stopping boundaries updated and saved to INI."));
        printStopBoundarySummary();
    }
}

void MainWindow::resetLocationFactors()
{
    lise_prompt_rad::resetLocationFactorsToDefaults();
    savePromptRadiationSettings();
    m_log->append(tr("\nLocation factors reset to FY2027 template defaults and saved to INI."));
    printLocationFactorSummary();
}

void MainWindow::resetStopLocationBoundaries()
{
    lise_prompt_rad::resetStopLocationBoundariesToDefaults();
    savePromptRadiationSettings();
    m_log->append(tr("\nDB0.x stopping boundaries reset to Excel/FY2027 defaults and saved to INI."));
    printStopBoundarySummary();
}

void MainWindow::runSmallExample()
{
    using namespace lise_prompt_rad;

    // Tiny placeholder example only. Replace these vectors with real LISE++ rows:
    // B:G from "Template Detailed" and B:C from "TemplatePositions".
    const std::vector<LiseDetailedInput> liseRows = {
        {"28Mg", 28, 12, "PF", 1.0e8, 175.0},
        {"31Al", 31, 13, "PF", 2.0e7, 170.0}
    };

    const std::vector<TemplatePosition> positions = {
        {"28Mg", -260.0},
        {"31Al", 40.0}
    };

    const DetailedDoseResult result = calculateDetailedTemplate(
        liseRows,
        positions,
        defaultLowIonRowsFY2027(),
        0.0);

    m_log->append(tr("\nSmall prompt-radiation example, including default low-ion rows:"));
    for (int i = 0; i < kMonitorCount; ++i) {
        m_log->append(QString::fromLatin1("  %1 : %2 mrem/h")
                      .arg(QString::fromLatin1(kMonitorNames[i]), -7)
                      .arg(result.totalsMremPerHr[i], 0, 'g', 8));
    }
}

void MainWindow::loadPromptRadiationSettings()
{
    QSettings settings(settingsFilePath(), QSettings::IniFormat);

    lise_prompt_rad::LocationFactorTable factors = lise_prompt_rad::defaultLocationFactors();

    settings.beginGroup("LocationFactors");
    for (int r = 0; r < lise_prompt_rad::kMonitorCount; ++r) {
        for (int c = 0; c < lise_prompt_rad::kLocationCount; ++c) {
            const QString key = QString::fromLatin1("%1/%2")
                                    .arg(QString::fromLatin1(lise_prompt_rad::kMonitorNames[r]),
                                         QString::fromLatin1(lise_prompt_rad::kLocationNames[c]));
            factors[r][c] = settings.value(key, factors[r][c]).toDouble();
        }
    }
    settings.endGroup();
    lise_prompt_rad::setLocationFactors(factors);

    lise_prompt_rad::StopBoundaryTable boundaries = lise_prompt_rad::defaultStopLocationBoundaries();
    settings.beginGroup("StopLocationBoundaries");
    for (int i = 0; i < lise_prompt_rad::kStopBoundaryCount; ++i) {
        const QString key = QString::fromLatin1("Limit%1").arg(i + 1);
        boundaries[i] = settings.value(key, boundaries[i]).toDouble();
    }
    settings.endGroup();
    lise_prompt_rad::setStopLocationBoundaries(boundaries);

    // Create/update the INI on first run so the user can edit it by hand if needed.
    savePromptRadiationSettings();
}

void MainWindow::savePromptRadiationSettings() const
{
    QSettings settings(settingsFilePath(), QSettings::IniFormat);

    settings.beginGroup("LocationFactors");
    const auto& factors = lise_prompt_rad::locationFactors();
    for (int r = 0; r < lise_prompt_rad::kMonitorCount; ++r) {
        for (int c = 0; c < lise_prompt_rad::kLocationCount; ++c) {
            const QString key = QString::fromLatin1("%1/%2")
                                    .arg(QString::fromLatin1(lise_prompt_rad::kMonitorNames[r]),
                                         QString::fromLatin1(lise_prompt_rad::kLocationNames[c]));
            settings.setValue(key, factors[r][c]);
        }
    }
    settings.endGroup();

    settings.beginGroup("StopLocationBoundaries");
    const auto& boundaries = lise_prompt_rad::stopLocationBoundaries();
    for (int i = 0; i < lise_prompt_rad::kStopBoundaryCount; ++i) {
        const QString key = QString::fromLatin1("Limit%1").arg(i + 1);
        settings.setValue(key, boundaries[i]);
    }
    settings.setValue("Rule", "x<Limit1:P2, x<Limit2:P3, x<Limit3:P4, x<Limit4:P5, x<Limit5:P4, x<Limit6:P3, else:P2");
    settings.endGroup();

    settings.sync();
}

void MainWindow::printLocationFactorSummary()
{
    const auto& f = lise_prompt_rad::locationFactors();

    m_log->append(tr("\nActive location factors for N0318:"));
    for (int c = 0; c < lise_prompt_rad::kLocationCount; ++c) {
        m_log->append(QString::fromLatin1("  %1 = %2")
                      .arg(QString::fromLatin1(lise_prompt_rad::kLocationNames[c]), -5)
                      .arg(f[0][c], 0, 'g', 12));
    }
}

void MainWindow::printStopBoundarySummary()
{
    const auto& b = lise_prompt_rad::stopLocationBoundaries();

    m_log->append(tr("\nActive DB0.x stopping boundaries [mm]:"));
    m_log->append(QString::fromLatin1("  x < %1  -> P2").arg(b[0], 0, 'g', 12));
    m_log->append(QString::fromLatin1("  x < %1  -> P3").arg(b[1], 0, 'g', 12));
    m_log->append(QString::fromLatin1("  x < %1  -> P4").arg(b[2], 0, 'g', 12));
    m_log->append(QString::fromLatin1("  x < %1  -> P5").arg(b[3], 0, 'g', 12));
    m_log->append(QString::fromLatin1("  x < %1  -> P4").arg(b[4], 0, 'g', 12));
    m_log->append(QString::fromLatin1("  x < %1  -> P3").arg(b[5], 0, 'g', 12));
    m_log->append(QStringLiteral("  else       -> P2"));
}
