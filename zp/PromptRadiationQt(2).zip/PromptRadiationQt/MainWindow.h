#pragma once

#include <QMainWindow>
#include <QString>

class QTextEdit;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override = default;

private slots:
    void editLocationFactors();
    void editStopLocationBoundaries();
    void runSmallExample();
    void resetLocationFactors();
    void resetStopLocationBoundaries();

private:
    void createMenus();
    QString settingsFilePath() const;
    void loadPromptRadiationSettings();
    void savePromptRadiationSettings() const;
    void printLocationFactorSummary();
    void printStopBoundarySummary();

    QTextEdit* m_log = nullptr;
};
