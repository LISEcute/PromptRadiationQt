# PromptRadiationQt

Standalone Qt Widgets example for the LISE++ prompt-radiation detailed-template calculation.

## What it contains

- `PromptRadiationDetailed.*` — C++ translation of the Excel `Template Detailed` calculations.
- `LocationFactorsModel.*` — editable Qt table model for the `kLocationFactors` values.
- `LocationFactorsDialog.*` — table dialog with copy/paste and reset-to-defaults.
- `StopBoundariesDialog.*` — editor for the DB0.x stopping-boundary limits used by the P2/P3/P4/P5 assignment.
- `MainWindow.*` — menu actions under `File` and `Calculations`:
  - `File / Prompt radiation: load INI...`
  - `File / Prompt radiation: save INI as...`
  - `File / Prompt radiation: use default INI`
  - `Calculations / Prompt radiation: edit location factors...`
  - `Prompt radiation: edit DB0.x stopping boundaries...`
  - `Prompt radiation: run small example`
  - `Prompt radiation: reset location factors`
  - `Prompt radiation: reset DB0.x stopping boundaries`

## DB0.x boundary logic

The old hard-coded logic was:

```cpp
if (db0xMm < -310.0) return StopLocation::P2;
if (db0xMm < -170.0) return StopLocation::P3;
if (db0xMm < -100.0) return StopLocation::P4;
if (db0xMm <  100.0) return StopLocation::P5;
if (db0xMm <  170.0) return StopLocation::P4;
if (db0xMm <  310.0) return StopLocation::P3;
return StopLocation::P2;
```

Now these six limits are stored in an editable table:

```cpp
using StopBoundaryTable = std::array<double, 6>;

const StopBoundaryTable& stopLocationBoundaries();
void setStopLocationBoundaries(const StopBoundaryTable& boundaries);
void resetStopLocationBoundariesToDefaults();
```

The active limits are used automatically by:

```cpp
lise_prompt_rad::locationFromDb0xExcel(db0xMm, hasDb0x);
lise_prompt_rad::calculateDetailedTemplate(...);
```

The dialog validates that the six values are strictly increasing.

## INI file

The example uses an explicit INI file, not the Windows registry:

```cpp
QSettings settings(settingsFilePath(), QSettings::IniFormat);
```

By default the file is created next to the executable:

```text
PromptRadiation.ini
```

The user can also load and save a different INI file from the `File` menu. After loading or saving-as another file, later edits are written to that selected file. `File / Prompt radiation: use default INI` switches back to the default `PromptRadiation.ini` next to the executable.

It stores both groups. Location factors are written as simple monitor/location keys so they are easy to edit by hand:

```ini
[LocationFactors]
N0318_P2=0.16
N0318_P2P3=0.20333333333333334
N0318_P3=0.29
N0318_P4=0.27
N0318_P5=0.015
...

[StopLocationBoundaries]
Limit1=-310
Limit2=-170
Limit3=-100
Limit4=100
Limit5=170
Limit6=310
Rule=x<Limit1:P2, x<Limit2:P3, x<Limit3:P4, x<Limit4:P5, x<Limit5:P4, x<Limit6:P3, else:P2
```

The source still keeps the hard-coded FY2027 defaults in `PromptRadiationDetailed.cpp` as `kDefaultLocationFactors` and `kDefaultStopLocationBoundaries`. If the INI file is missing or incomplete, those source defaults are used. Pressing `reset location factors` or `reset DB0.x stopping boundaries` restores the source defaults and writes them back to the INI file.

For direct LISE++ integration, change only `MainWindow::defaultSettingsFilePath()` if you want to use an existing LISE++ settings directory. The currently selected file is stored in `m_settingsFilePath` during the session.

## Build in Qt Creator

Open `PromptRadiationQt.pro`, select a Desktop Qt kit, then Build/Run.

## Integration into LISE++

Move the files into LISE++ and connect the actions like in `MainWindow::createMenus()`:

```cpp
QAction* editFactorsAction = calcMenu->addAction(tr("Prompt radiation: edit location factors..."));
connect(editFactorsAction, &QAction::triggered, this, &MainWindow::editLocationFactors);

QAction* editBoundariesAction = calcMenu->addAction(tr("Prompt radiation: edit DB0.x stopping boundaries..."));
connect(editBoundariesAction, &QAction::triggered, this, &MainWindow::editStopLocationBoundaries);
```

Load settings once before running the calculation, and save after the user accepts either editor dialog.

## Icons

The project now includes a small `Icons/` folder copied from the LISE++ icon archive:

- `sign_ok.png` for OK buttons
- `cancel.png` for Cancel buttons
- `copy.png` for Copy buttons
- `paste1.png` for Paste buttons
- `lisepp_small.png` as the runtime application/window/dialog icon
- `lise_small_new.ico` as the Windows executable icon through `RC_ICONS`

The Qt resource file is `PromptRadiationResources.qrc`. Dialog buttons use the resource paths such as `:/Icons/sign_ok.png`.
